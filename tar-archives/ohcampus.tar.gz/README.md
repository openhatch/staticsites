oh-campus-foss
==============

Website explaining the student immersion program.  Issues should be filed in the [Open Source Comes to Campus repo](https://github.com/openhatch/open-source-comes-to-campus/).


How to run locally
============

After you've forked and cloned this repo, go into the repo and run the following command on your terminal:

`python -m SimpleHTTPServer`

<?php
if ($_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')
       $_SERVER['HTTPS']='on'; /* Disabled by Asheesh. This "fixes" the blog.*/
phpinfo();
?>

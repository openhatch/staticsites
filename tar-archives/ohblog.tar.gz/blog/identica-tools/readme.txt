Identi.ca Tools

Matt White (matt@cleversitename.com)
http://vikingisaverb.com/identica-tools.html

This plugin is heavily based on Alex King's original Twitter Tools plugin,
available at http://alexking.org/projects/wordpress. As the Identi.ca
(http://identi.ca) microblogging service has a 100% Twitter-compatible API, it
was trivial to adapt his plugin. If you find this useful, please visit Alex
King's website and donate. He's the one who did all the real programming work;
most of the work I did was simple string searching-and-replacing.

Many thanks also to Evan Prodromou and the rest of the good folks at
Laconi.ca (http://laconi.ca) and Identi.ca (http://identi.ca). Their hard
work on implementing the Twitter-compatible API greatly simplified this
port.

oh-events-harvard
=================

website for Harvard OSCTC event